"""Email HTML templates"""
from datetime import datetime

class EmailTemplates:
    @staticmethod
    def business_notification(lead_data: dict) -> str:
        quote_number = lead_data.get('quote_number', 'N/A')
        return f"""<!DOCTYPE html>
<html><head><style>
body{{font-family:'Inter',Arial,sans-serif;line-height:1.6;color:#4A3F35}}
.container{{max-width:600px;margin:0 auto;padding:20px}}
.header{{background:linear-gradient(135deg,#C17453 0%,#A86243 100%);color:white;padding:30px;text-align:center;border-radius:8px 8px 0 0}}
.header h1{{margin:0;font-family:'Playfair Display',serif;font-size:28px}}
.quote-number{{background:rgba(255,255,255,0.2);padding:12px 24px;border-radius:30px;display:inline-block;margin-top:12px;font-size:20px;font-weight:bold;letter-spacing:1px}}
.content{{background:#FAF7F2;padding:30px;border-radius:0 0 8px 8px}}
.field{{margin-bottom:20px}}
.label{{font-weight:600;color:#8B6F47;font-size:14px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:5px}}
.value{{font-size:16px;color:#4A3F35;background:white;padding:12px;border-radius:6px;border-left:3px solid #C17453}}
.cta{{text-align:center;margin-top:30px}}
.cta a{{background:#C17453;color:white;padding:15px 30px;text-decoration:none;border-radius:6px;display:inline-block;font-weight:600}}
.footer{{text-align:center;margin-top:30px;color:#8B6F47;font-size:12px}}
</style></head><body>
<div class="container">
<div class="header"><h1>New Quote Request</h1>
<div class="quote-number">Quote ID: {quote_number}</div>
<p style="margin:10px 0 0 0;opacity:0.9">Someone is interested in your services!</p></div>
<div class="content">
<div class="field"><div class="label">Quote ID</div><div class="value">{quote_number}</div></div>
<div class="field"><div class="label">Customer Name</div><div class="value">{lead_data['name']}</div></div>
<div class="field"><div class="label">Phone Number</div><div class="value">+91 {lead_data['phone']}</div></div>
<div class="field"><div class="label">Area/Location</div><div class="value">{lead_data['area']}</div></div>
<div class="field"><div class="label">Service Interested In</div><div class="value">{lead_data['service']}</div></div>
<div class="field"><div class="label">Budget Range</div><div class="value">{lead_data['budget']}</div></div>
{f'<div class="field"><div class="label">Message</div><div class="value">{lead_data["message"]}</div></div>' if lead_data.get('message') else ''}
<div class="field"><div class="label">Submitted At</div><div class="value">{datetime.now().strftime('%d %B %Y, %I:%M %p')}</div></div>
<div class="cta"><a href="https://wa.me/91{lead_data['phone']}?text=Hi%20{lead_data['name']}">Contact via WhatsApp</a></div>
</div>
<div class="footer"><p>Automated notification from Millenial Architects</p></div>
</div></body></html>"""
    
    @staticmethod
    def customer_confirmation(lead_data: dict) -> str:
        quote_number = lead_data.get('quote_number', 'N/A')
        return f"""<!DOCTYPE html>
<html><head><style>
body{{font-family:'Inter',Arial,sans-serif;line-height:1.6;color:#4A3F35}}
.container{{max-width:600px;margin:0 auto;padding:20px}}
.header{{background:linear-gradient(135deg,#C17453 0%,#A86243 100%);color:white;padding:40px 30px;text-align:center;border-radius:8px 8px 0 0}}
.header h1{{margin:0;font-family:'Playfair Display',serif;font-size:32px}}
.quote-id-box{{background:rgba(255,255,255,0.2);padding:16px 24px;border-radius:12px;margin:20px auto;display:inline-block}}
.quote-id-label{{font-size:14px;opacity:0.9;margin-bottom:4px}}
.quote-id-value{{font-size:24px;font-weight:bold;letter-spacing:2px}}
.content{{background:#FAF7F2;padding:30px;border-radius:0 0 8px 8px}}
.greeting{{font-size:18px;margin-bottom:20px}}
.message{{background:white;padding:20px;border-radius:6px;border-left:4px solid #D4AF37;margin:20px 0}}
.details{{background:white;padding:20px;border-radius:6px;margin:20px 0}}
.detail-row{{display:flex;padding:10px 0;border-bottom:1px solid #EDE7DD}}
.detail-label{{font-weight:600;color:#8B6F47;min-width:120px}}
.detail-value{{color:#4A3F35}}
.cta{{text-align:center;margin:30px 0}}
.cta a{{background:#25D366;color:white;padding:15px 30px;text-decoration:none;border-radius:6px;display:inline-block;font-weight:600;margin:5px}}
.footer{{text-align:center;margin-top:30px;padding-top:20px;border-top:1px solid #EDE7DD;color:#8B6F47;font-size:14px}}
</style></head><body>
<div class="container">
<div class="header"><h1>Millenial Architects</h1>
<p style="margin:10px 0 0 0;font-size:16px;opacity:0.9">Transforming homes, creating dreams</p>
<div class="quote-id-box"><div class="quote-id-label">Your Quote ID</div><div class="quote-id-value">{quote_number}</div></div></div>
<div class="content">
<div class="greeting">Hi {lead_data['name']},</div>
<div class="message">
<p style="margin:0 0 15px 0;font-size:16px">Thank you for your interest in Millenial Architects! We're excited to help transform your space.</p>
<p style="margin:0;font-size:16px">We've received your quote request and our team will get back to you within 24 hours.</p>
</div>
<h3 style="color:#4A3F35;font-family:'Playfair Display',serif;margin-top:30px">Your Request Details:</h3>
<div class="details">
<div class="detail-row"><div class="detail-label">Quote ID:</div><div class="detail-value" style="font-weight:700;color:#C17453">{quote_number}</div></div>
<div class="detail-row"><div class="detail-label">Service:</div><div class="detail-value">{lead_data['service']}</div></div>
<div class="detail-row"><div class="detail-label">Location:</div><div class="detail-value">{lead_data['area']}</div></div>
<div class="detail-row"><div class="detail-label">Budget Range:</div><div class="detail-value">{lead_data['budget']}</div></div>
</div>
<div class="cta"><a href="https://wa.me/918551904280?text=Hi">Chat with Us on WhatsApp</a></div>
</div>
<div class="footer">
<p style="margin:0 0 10px 0;font-weight:600">Contact Us</p>
<p style="margin:5px 0">📞 +91 85519 04280</p>
<p style="margin:15px 0 0 0;font-size:12px">© 2026 Millenial Architects. All rights reserved.</p>
</div></div></body></html>"""
