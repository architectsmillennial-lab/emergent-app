"""Production-ready email service for Resend API"""
from .service import EmailService
from .config import email_config, EmailMode

__all__ = ['EmailService', 'email_config', 'EmailMode']