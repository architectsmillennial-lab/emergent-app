"""High-level email service with business logic"""
import logging
from .config import email_config, EmailMode
from .transport import ResendTransport, EmailSandboxError, EmailAPIError, EmailTransportError
from .templates import EmailTemplates

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        self.config = email_config
        self.transport = ResendTransport(self.config)
        self.templates = EmailTemplates()
        self.stats = {"sent": 0, "failed": 0, "sandbox_blocked": 0, "disabled_skipped": 0}
    
    async def send_lead_notification(self, lead_data: dict) -> bool:
        if self.config.mode == EmailMode.DISABLED:
            logger.warning("Email disabled - skipping business notification")
            self.stats["disabled_skipped"] += 1
            return False
        
        quote_number = lead_data.get('quote_number', 'N/A')
        subject = f"🏠 New Quote Request - {quote_number} - {lead_data['name']}"
        html_content = self.templates.business_notification(lead_data)
        
        try:
            await self.transport.send(self.config.business_email, subject, html_content)
            self.stats["sent"] += 1
            logger.info(f"✅ Business notification sent for {quote_number}")
            return True
        except EmailSandboxError as e:
            self.stats["sandbox_blocked"] += 1
            logger.info(f"📧 Sandbox blocked: {e}")
            return False
        except (EmailAPIError, EmailTransportError, Exception) as e:
            self.stats["failed"] += 1
            logger.error(f"❌ Failed to send business notification: {e}")
            return False
    
    async def send_customer_confirmation(self, lead_data: dict) -> bool:
        if self.config.mode == EmailMode.DISABLED:
            logger.warning("Email disabled - skipping customer confirmation")
            self.stats["disabled_skipped"] += 1
            return False
        
        customer_email = lead_data.get('email')
        if not customer_email:
            logger.info("No customer email - skipping confirmation")
            return False
        
        quote_number = lead_data.get('quote_number', 'N/A')
        subject = f"Your Quote Request Confirmed - {quote_number}"
        html_content = self.templates.customer_confirmation(lead_data)
        
        try:
            await self.transport.send(customer_email, subject, html_content)
            self.stats["sent"] += 1
            logger.info(f"✅ Customer confirmation sent to {customer_email}")
            return True
        except EmailSandboxError as e:
            self.stats["sandbox_blocked"] += 1
            logger.info(f"📧 Cannot send to {customer_email} in sandbox mode (will work in production)")
            return False
        except (EmailAPIError, EmailTransportError, Exception) as e:
            self.stats["failed"] += 1
            logger.error(f"❌ Failed to send customer confirmation: {e}")
            return False
    
    def get_stats(self) -> dict:
        return {**self.stats, "mode": self.config.mode.value, "domain_configured": bool(self.config.domain)}
