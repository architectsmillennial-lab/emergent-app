"""Resend API transport layer with retry logic"""
import httpx
import logging
from typing import Optional, Dict, Any
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

logger = logging.getLogger(__name__)

class EmailTransportError(Exception):
    pass

class EmailSandboxError(EmailTransportError):
    pass

class EmailAPIError(EmailTransportError):
    pass

class ResendTransport:
    def __init__(self, config):
        self.config = config
        self.api_url = config.api_url
        self.api_key = config.api_key
        self.timeout = config.timeout
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.NetworkError))
    )
    async def send(self, to_email: str, subject: str, html_content: str, reply_to: Optional[str] = None) -> Dict[str, Any]:
        if not self.config.can_send_to(to_email):
            raise EmailSandboxError(f"Cannot send to {to_email} in {self.config.mode} mode")
        
        payload = {
            "from": f"Millenial Architects <{self.config.from_email}>",
            "to": [to_email],
            "subject": subject,
            "html": html_content,
        }
        if reply_to:
            payload["reply_to"] = reply_to
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(self.api_url, headers=headers, json=payload)
                
                if response.status_code >= 400:
                    error_detail = response.text
                    if response.status_code == 403:
                        raise EmailSandboxError(f"Resend sandbox restriction (403): {error_detail}")
                    raise EmailAPIError(f"Resend API error {response.status_code}: {error_detail}")
                
                result = response.json()
                logger.info(f"✅ Email sent to {to_email}", extra={"email_id": result.get('id')})
                return result
        
        except httpx.TimeoutException as e:
            raise EmailTransportError(f"Email timeout: {e}")
        except httpx.HTTPError as e:
            raise EmailTransportError(f"HTTP error: {e}")
        except (EmailSandboxError, EmailAPIError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            raise EmailTransportError(f"Unexpected error: {e}")
