"""Email configuration with automatic sandbox/production mode detection"""
import os
import logging
from enum import Enum

logger = logging.getLogger(__name__)

class EmailMode(str, Enum):
    SANDBOX = "sandbox"
    PRODUCTION = "production"
    DISABLED = "disabled"

class EmailConfig:
    def __init__(self):
        self.api_key = os.environ.get("RESEND_API_KEY")
        self.from_email = os.environ.get("FROM_EMAIL", "onboarding@resend.dev")
        self.business_email = os.environ.get("BUSINESS_EMAIL", self.from_email)
        self.domain = os.environ.get("EMAIL_DOMAIN")
        self.mode = self._detect_mode()
        self.sandbox_whitelist = self._get_sandbox_whitelist()
        self.api_url = "https://api.resend.com/emails"
        self.timeout = 10.0
        self.max_retries = 3
        self._log_config()
    
    def _detect_mode(self) -> EmailMode:
        if not self.api_key:
            logger.warning("⚠️  RESEND_API_KEY not set - Email service DISABLED")
            return EmailMode.DISABLED
        if self.domain:
            logger.info(f"✅ Email domain configured: {self.domain} - PRODUCTION mode")
            return EmailMode.PRODUCTION
        logger.warning("⚠️  No EMAIL_DOMAIN set - Running in SANDBOX mode")
        return EmailMode.SANDBOX
    
    def _get_sandbox_whitelist(self) -> set:
        whitelist = {self.business_email, self.from_email}
        extra = os.environ.get("SANDBOX_WHITELIST", "")
        if extra:
            whitelist.update([email.strip() for email in extra.split(",") if email.strip()])
        return {email for email in whitelist if email}
    
    def can_send_to(self, recipient: str) -> bool:
        if self.mode == EmailMode.DISABLED:
            return False
        if self.mode == EmailMode.PRODUCTION:
            return True
        is_allowed = recipient in self.sandbox_whitelist
        if not is_allowed:
            logger.info(f"📧 Cannot send to {recipient} in SANDBOX mode")
        return is_allowed
    
    def _log_config(self):
        logger.info("=" * 60)
        logger.info("📧 Email Service Configuration")
        logger.info(f"Mode: {self.mode.value.upper()}")
        logger.info(f"From: {self.from_email}")
        logger.info(f"Business: {self.business_email}")
        if self.mode == EmailMode.SANDBOX:
            logger.info(f"Whitelist: {', '.join(self.sandbox_whitelist)}")
        logger.info("=" * 60)

email_config = EmailConfig()