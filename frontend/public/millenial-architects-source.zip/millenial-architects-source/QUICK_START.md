# Quick Start Guide - Millenial Architects

## What's Included
✅ Complete React frontend (landing page)
✅ FastAPI backend (API + email service)
✅ MongoDB integration
✅ Email notification system
✅ All source code & configurations

## Your Credentials (KEEP SAFE!)
- **Gmail:** architectsmillennial@gmail.com
- **App Password:** tlurzumbflbqhmnd
- **WhatsApp:** +91 8551904280

## Fastest Way to Deploy (5 minutes)

### Option 1: Railway.app (Easiest - All in One)
1. Go to https://railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Upload this folder
5. Add environment variables (see backend/.env.example)
6. Done! Get your live URL

**Cost:** $5/month (includes everything)

### Option 2: Netlify + Render (Free)
1. **Backend on Render:**
   - Upload `backend/` folder to Render.com
   - Add environment variables
   - Get backend URL

2. **Frontend on Netlify:**
   - Update `frontend/.env` with backend URL
   - Run `cd frontend && yarn build`
   - Upload `build/` folder to Netlify
   - Done!

**Cost:** Free (backend sleeps after inactivity)

## First Time Setup (Local Testing)

1. **Install Dependencies:**
   ```bash
   # Frontend
   cd frontend
   yarn install
   
   # Backend
   cd ../backend
   pip install -r requirements.txt
   ```

2. **Set Environment Variables:**
   - Copy `.env.example` to `.env` in both folders
   - Update with your credentials

3. **Run Locally:**
   ```bash
   # Terminal 1 - Backend
   cd backend
   uvicorn server:app --reload --port 8001
   
   # Terminal 2 - Frontend
   cd frontend
   yarn start
   ```

4. **Test:** Open http://localhost:3000

## Need Help?
Read DEPLOYMENT.md for detailed instructions on:
- MongoDB Atlas setup
- Custom domain configuration
- Email notification testing
- Troubleshooting

## Important Files
- `frontend/src/pages/LandingPage.jsx` - Main landing page
- `backend/server.py` - API endpoints
- `backend/services/email_service.py` - Email templates
- `frontend/src/data/mock.js` - Service/testimonial data

## Customization
Want to change content? Edit these:
- **Company info:** Search for "Millenial Architects" in code
- **WhatsApp number:** Search for "8551904280"
- **Services:** Edit `frontend/src/data/mock.js`
- **Images:** Replace Unsplash URLs with your photos
- **Email templates:** Edit `backend/services/email_service.py`

---

**Ready to launch? Follow DEPLOYMENT.md for step-by-step instructions!**
